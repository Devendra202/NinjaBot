# imdb-clone-cn

This is a Imdb clone website for movie searching.

i have created this project using html css and javascript.

This website is created assuming three section:

i. Header section: this section has been built for only containing the heading name of the webiste.

ii. Search section: this section is created for searching the movies by thei name.

iii. Result section: result section contains all details of the movie which has been search by the user.

![2023-03-13 (1)](https://user-images.githubusercontent.com/120048006/224763062-0559b683-89c2-4ecc-b4a7-a375e800dea9.png)


![2023-03-13 (2)](https://user-images.githubusercontent.com/120048006/224763227-d1e89608-430f-45cf-934f-d23512213a21.png)

![2023-03-13 (3)](https://user-images.githubusercontent.com/120048006/224763414-fa1e8a72-4ad7-4670-a93c-a22895466223.png)

![2023-03-13 (4)](https://user-images.githubusercontent.com/120048006/224763657-f2acf10c-e540-4721-9ab4-70f4f5376029.png)
